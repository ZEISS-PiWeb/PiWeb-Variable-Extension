'use strict';

import * as piweb from 'piweb'

piweb.events.on("calculate", calculate);

function calculate() : piweb.expressions.ExpressionDataType {

	return "MyResult";
}